const $ = id => document.getElementById(id);
const HF_SPACE = "https://prithivmlmods-wan22-fast.hf.space";
const NEGATIVE = "static image, frozen motion, blurry, low quality, distorted face, deformed hands, extra fingers, text, watermark, duplicate people";
let photos = [], trackFile = null, trackURL = null, busy = false;

const photoInput = $("photos"), trackInput = $("track"), audio = $("audio"), createBtn = $("create");
photoInput.addEventListener("change", () => {
  const files = [...photoInput.files].filter(f => f.type.startsWith("image/"));
  files.forEach(f => {
    if (photos.length < 8) photos.push({file:f, url:URL.createObjectURL(f)});
  });
  renderPhotos(); updateReady();
});
trackInput.addEventListener("change", () => {
  const f = trackInput.files[0]; if (!f) return;
  if (trackURL) URL.revokeObjectURL(trackURL);
  trackFile = f; trackURL = URL.createObjectURL(f);
  audio.src = trackURL; audio.hidden = false;
  $("trackInfo").innerHTML = `<strong>♫ ${escapeHTML(f.name)}</strong> · ${(f.size/1048576).toFixed(1)} МБ`;
  updateReady();
});
function escapeHTML(s) {
  return String(s).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}
function renderPhotos() {
  $("photoList").innerHTML = photos.length
    ? photos.map(p => `<img class="thumb" src="${p.url}" alt="Загруженное фото">`).join("")
    : '<span class="empty">Пока нет загруженных фото</span>';
}
function updateReady() {
  createBtn.disabled = !(photos.length && trackFile) || busy;
  if (!busy) $("message").textContent = createBtn.disabled
    ? "Добавь фото и музыкальный трек."
    : "Готово. Будут созданы 3 AI-видео по 5 секунд.";
}
const themes = [
  {name:"NEON PULSE", desc:"Неоновые огни, кинематографичное движение", color:"#5cf5ff",
   prompt:"Animate the person in the source photo naturally while preserving their exact identity, facial features, hairstyle and clothing. Cinematic neon cyan and violet lighting, slow confident camera push-in, subtle hair and clothing movement, glowing city lights in the background, atmospheric music video, realistic motion."},
  {name:"NIGHT DRIVE", desc:"Ночной город и динамичная камера", color:"#ff4ecb",
   prompt:"Bring the source photo to life. Preserve the person's identity, face, hairstyle and outfit exactly. Night city at dusk, magenta neon reflections, gentle handheld camera movement, passing light streaks in the background, cinematic underground hip-hop music video, realistic natural motion."},
  {name:"DREAM FLOW", desc:"Мягкий свет и плавная атмосфера", color:"#b7ffef",
   prompt:"Animate the source photo into a dreamy cinematic music video. Keep the person's face, identity, hairstyle and clothing unchanged. Soft atmospheric light, floating particles, gentle breeze moving hair and fabric, smooth slow orbit camera, elegant realistic motion, subtle violet and pink glow."}
];
createBtn.addEventListener("click", createVideos);

async function createVideos() {
  if (busy || !photos.length || !trackFile) return;
  busy = true; updateReady();
  $("results").hidden = false;
  $("variantGrid").innerHTML = "";
  const idea = $("idea").value.trim();
  try {
    const imageData = await prepareImage(photos[0].file);
    for (let i = 0; i < themes.length; i++) {
      const theme = themes[i];
      const card = makeCard(theme);
      $("variantGrid").append(card);
      setStatus(`Создаём видео ${i+1} из 3. Это может занять несколько минут…`);
      const prompt = [theme.prompt, idea ? `Additional scene direction: ${idea}.` : ""].filter(Boolean).join(" ");
      const videoData = await requestVideo(imageData, prompt, i);
      const blob = dataUriToBlob(videoData);
      if (!blob || !blob.size) throw new Error("Модель вернула пустой видеофайл.");
      const videoURL = URL.createObjectURL(blob);
      const player = card.querySelector("video");
      player.src = videoURL;
      player.hidden = false;
      const save = card.querySelector("button");
      save.disabled = false;
      save.textContent = "СОХРАНИТЬ MP4";
      save.addEventListener("click", () => saveVideo(blob, `neon-beats-${theme.name.toLowerCase().replaceAll(" ","-")}.mp4`, save));
      card.querySelector(".variant-state").textContent = "Готово · MP4 · 5 секунд";
    }
    setStatus("Готово: созданы три AI-видео. В этой версии MP4 пока без музыкальной дорожки.");
  } catch (e) {
    setStatus("Ошибка генерации: " + friendlyError(e));
  } finally {
    busy = false; updateReady();
  }
}
function makeCard(theme) {
  const card = document.createElement("article");
  card.className = "variant";
  card.innerHTML = `<video controls playsinline hidden></video><h4>${theme.name}</h4><p>${theme.desc}</p><small class="variant-state">Ожидает генерации…</small><button type="button" disabled>ОЖИДАНИЕ</button>`;
  return card;
}
function setStatus(message) { $("message").textContent = message; }
function friendlyError(e) {
  const m = e && e.message ? e.message : String(e);
  if (/Failed to fetch|NetworkError|CORS/i.test(m)) return "не удалось связаться с сервером. Проверь интернет и повтори попытку.";
  if (/queue|GPU|ZeroGPU|quota|rate limit|429/i.test(m)) return "сервер занят или закончилась бесплатная GPU-квота. Попробуй позже.";
  return m;
}
async function prepareImage(file) {
  const image = await new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file), img = new Image();
    img.onload = () => { URL.revokeObjectURL(url); resolve(img); };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error("Не удалось открыть фотографию.")); };
    img.src = url;
  });
  const max = 832, scale = Math.min(1, max / Math.max(image.width, image.height));
  const canvas = document.createElement("canvas");
  canvas.width = Math.max(1, Math.round(image.width * scale));
  canvas.height = Math.max(1, Math.round(image.height * scale));
  canvas.getContext("2d").drawImage(image, 0, 0, canvas.width, canvas.height);
  return canvas.toDataURL("image/jpeg", 0.88);
}
async function requestVideo(imageB64, prompt, index) {
  const payload = {
    data: [imageB64, prompt, 4, NEGATIVE, 5.0, 1, 1, 1000 + index, true]
  };
  const start = await fetch(`${HF_SPACE}/gradio_api/call/generate_video`, {
    method:"POST",
    headers:{"Content-Type":"application/json"},
    body:JSON.stringify(payload)
  });
  if (!start.ok) throw new Error(`Сервер отклонил запрос (${start.status}).`);
  const startData = await start.json();
  if (!startData.event_id) throw new Error(startData.error || "Сервер не создал задачу.");
  const response = await fetch(`${HF_SPACE}/gradio_api/call/generate_video/${encodeURIComponent(startData.event_id)}`);
  if (!response.ok || !response.body) throw new Error(`Не удалось получить результат (${response.status}).`);
  const reader = response.body.getReader(), decoder = new TextDecoder();
  let buffer = "";
  while (true) {
    const {value, done} = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, {stream:true});
    const events = buffer.split(/\r?\n\r?\n/);
    buffer = events.pop() || "";
    for (const eventText of events) {
      const eventName = (eventText.match(/^event:\s*(.+)$/m) || [])[1] || "";
      const dataText = eventText.split(/\r?\n/).filter(line => line.startsWith("data:")).map(line => line.slice(5).trim()).join("\n");
      if (!dataText) continue;
      if (eventName === "error") throw new Error(dataText);
      if (eventName === "complete") return extractVideo(JSON.parse(dataText));
    }
  }
  if (buffer.includes("event: complete")) {
    const dataText = (buffer.match(/^data:\s*(.+)$/m) || [])[1];
    if (dataText) return extractVideo(JSON.parse(dataText));
  }
  throw new Error("Сервер завершил соединение без готового видео.");
}
function extractVideo(result) {
  let value = Array.isArray(result) ? result[0] : result;
  if (value && typeof value === "object" && value.video) value = value.video;
  if (typeof value !== "string") throw new Error("Неизвестный формат ответа видеогенератора.");
  return value.startsWith("data:") ? value : `data:video/mp4;base64,${value}`;
}
function dataUriToBlob(dataUri) {
  const parts = dataUri.split(",");
  if (parts.length < 2) throw new Error("Повреждённый MP4-файл.");
  const mime = (parts[0].match(/data:([^;]+)/) || [])[1] || "video/mp4";
  const binary = atob(parts.slice(1).join(","));
  const bytes = new Uint8Array(binary.length);
  for (let i=0;i<binary.length;i++) bytes[i] = binary.charCodeAt(i);
  return new Blob([bytes], {type:mime});
}
function saveVideo(blob, name, button) {
  button.disabled = true; button.textContent = "СОХРАНЯЕМ…";
  const reader = new FileReader();
  reader.onload = () => {
    if (window.Android && typeof window.Android.saveVideo === "function") {
      window.Android.saveVideo(name, reader.result);
    } else {
      const url = URL.createObjectURL(blob), a = document.createElement("a");
      a.href = url; a.download = name; a.click();
      setTimeout(() => URL.revokeObjectURL(url), 60000);
      button.disabled = false; button.textContent = "СОХРАНИТЬ ЕЩЁ РАЗ";
    }
  };
  reader.onerror = () => { button.disabled = false; button.textContent = "ОШИБКА СОХРАНЕНИЯ"; };
  reader.readAsDataURL(blob);
}
window.onNativeSaveResult = (name, ok, message) => {
  const buttons = [...document.querySelectorAll(".variant button")];
  buttons.forEach(b => { if (b.disabled && b.textContent === "СОХРАНЯЕМ…") { b.disabled=false; b.textContent=ok?"СОХРАНЕНО":"ОШИБКА"; }});
  setStatus(ok ? `Сохранено в папку Movies/NEON BEATS AI: ${name}` : `Не удалось сохранить: ${message}`);
};
