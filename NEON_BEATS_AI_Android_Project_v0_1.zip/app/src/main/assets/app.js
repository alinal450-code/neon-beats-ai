const $=id=>document.getElementById(id);
let photos=[], trackFile=null, trackURL=null;
const photoInput=$("photos"), trackInput=$("track"), audio=$("audio"), createBtn=$("create");
photoInput.addEventListener("change",()=>{
  const files=[...photoInput.files].slice(0,8);
  files.forEach(f=>{if(f.type.startsWith("image/")) photos.push({file:f,url:URL.createObjectURL(f)});});
  photos=photos.slice(0,8); renderPhotos(); updateReady();
});
trackInput.addEventListener("change",()=>{
  const f=trackInput.files[0]; if(!f)return;
  if(trackURL)URL.revokeObjectURL(trackURL);
  trackFile=f;trackURL=URL.createObjectURL(f);audio.src=trackURL;audio.hidden=false;
  $("trackInfo").innerHTML=`<strong>♫ ${escapeHTML(f.name)}</strong> · ${(f.size/1048576).toFixed(1)} МБ`;
  updateReady();
});
function escapeHTML(s){return s.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function renderPhotos(){
  $("photoList").innerHTML=photos.length?photos.map(p=>`<img class="thumb" src="${p.url}" alt="Загруженное фото">`).join(""):'<span class="empty">Пока нет загруженных фото</span>';
}
function updateReady(){createBtn.disabled=!(photos.length&&trackFile);$("message").textContent=createBtn.disabled?"Добавь хотя бы одно фото и музыкальный трек.":"Всё готово. Можно создавать три варианта."; }
const themes=[
 {name:"NEON PULSE",desc:"Плавное движение и яркие световые акценты",a:"#5cf5ff",b:"#9a55ff"},
 {name:"NIGHT DRIVE",desc:"Более тёмная атмосфера и быстрые вспышки",a:"#ff4ecb",b:"#4b75ff"},
 {name:"DREAM FLOW",desc:"Мягкий свет, плавный зум и воздушные переходы",a:"#b7ffef",b:"#a66bff"}
];
createBtn.addEventListener("click",async()=>{
 if(!photos.length||!trackFile)return;
 createBtn.disabled=true;$("message").textContent="Готовим три визуальных концепта…";
 await loadImages();
 $("results").hidden=false;$("variantGrid").innerHTML="";
 themes.forEach((t,i)=>{
  const card=document.createElement("article");card.className="variant";
  card.innerHTML=`<canvas width="360" height="640"></canvas><h4>${t.name}</h4><p>${t.desc}</p><button type="button">СОХРАНИТЬ ВИДЕО · WEBM</button>`;
  $("variantGrid").append(card);
  const canvas=card.querySelector("canvas");drawPoster(canvas,t,i);
  card.querySelector("button").addEventListener("click",()=>recordVariant(canvas,t,i,card.querySelector("button")));
 });
 $("message").textContent="Концепты готовы. Нажми «Сохранить видео» под нужным вариантом. Экспорт — экспериментальный формат WebM.";
 createBtn.disabled=false;
});
function drawPoster(c,t,i){
 const x=c.getContext("2d"),g=x.createLinearGradient(0,0,360,640);g.addColorStop(0,"#17102c");g.addColorStop(1,"#05050d");x.fillStyle=g;x.fillRect(0,0,360,640);
 x.strokeStyle=t.a;x.globalAlpha=.5;x.lineWidth=2;
 for(let k=0;k<8;k++){x.beginPath();x.arc(180,300,55+k*23,0,Math.PI*2);x.stroke();}
 x.globalAlpha=1;
 const img=photos[i%photos.length].img;
 if(img){x.save();x.beginPath();x.roundRect(30,90,300,390,18);x.clip();const s=Math.max(300/img.width,390/img.height);const w=img.width*s,h=img.height*s;x.drawImage(img,(360-w)/2,(90+390-h)/2,w,h);x.restore();}
 x.fillStyle=t.a;x.font="bold 13px sans-serif";x.fillText("NEON BEATS AI",24,40);
 x.fillStyle="#fff";x.font="bold 28px sans-serif";x.fillText(t.name,24,535);
 x.fillStyle="#b9b1d1";x.font="12px sans-serif";x.fillText("30 SEC · VISUAL CONCEPT",24,560);
}
async function loadImages(){
 for(const p of photos){if(!p.img){p.img=await new Promise((res,rej)=>{const im=new Image();im.onload=()=>res(im);im.onerror=rej;im.src=p.url;});}}
}
async function recordVariant(canvas,t,index,button){
 try{
  await loadImages();
  const duration=30,ctx=canvas.getContext("2d"),stream=canvas.captureStream(30);
  const audioCtx=new (window.AudioContext||window.webkitAudioContext)();
  const playback=new Audio(trackURL);
  playback.preload="auto";
  const source=audioCtx.createMediaElementSource(playback);
  const dest=audioCtx.createMediaStreamDestination();source.connect(dest);source.connect(audioCtx.destination);
  dest.stream.getAudioTracks().forEach(track=>stream.addTrack(track));
  const mime=["video/webm;codecs=vp9,opus","video/webm;codecs=vp8,opus","video/webm"].find(m=>MediaRecorder.isTypeSupported(m));
  if(!mime)throw new Error("Этот браузер не поддерживает запись видео.");
  const recorder=new MediaRecorder(stream,{mimeType:mime,videoBitsPerSecond:5000000});
  const chunks=[];recorder.ondataavailable=e=>{if(e.data.size)chunks.push(e.data);};
  const done=new Promise(resolve=>recorder.onstop=()=>resolve(new Blob(chunks,{type:mime})));
  button.disabled=true;button.textContent="ЗАПИСЫВАЕМ…";
  playback.currentTime=0;await audioCtx.resume();await playback.play();recorder.start();
  const start=performance.now();
  await new Promise(resolve=>{
   function frame(now){
    const elapsed=(now-start)/1000;paintFrame(ctx,elapsed,t,index);
    if(elapsed<duration && !playback.ended)requestAnimationFrame(frame);else resolve();
   }requestAnimationFrame(frame);
  });
  recorder.stop();playback.pause();const blob=await done;
  const url=URL.createObjectURL(blob),a=document.createElement("a");a.href=url;a.download=`neon-beats-${t.name.toLowerCase().replaceAll(" ","-")}.webm`;a.click();
  setTimeout(()=>URL.revokeObjectURL(url),60000);
  button.textContent="СОХРАНИТЬ ЕЩЁ РАЗ";button.disabled=false;
  await audioCtx.close();
 }catch(e){button.disabled=false;button.textContent="ПОПРОБОВАТЬ СНОВА";$("message").textContent="Не удалось записать: "+e.message;}
}
function paintFrame(ctx,time,t,index){
 const w=360,h=640;ctx.fillStyle="#070612";ctx.fillRect(0,0,w,h);
 const pulse=1+Math.sin(time*3+index)*.025, img=photos[Math.floor(time/5)%photos.length].img;
 if(img){const scale=Math.max(w/img.width,h/img.height)*pulse;const iw=img.width*scale,ih=img.height*scale;const drift=Math.sin(time*.55+index)*12;ctx.save();ctx.filter="saturate(1.1) contrast(1.05)";ctx.drawImage(img,(w-iw)/2+drift,(h-ih)/2,iw,ih);ctx.restore();}
 const fade=Math.min(1,time/1.2,(30-time)/1.2);ctx.fillStyle=`rgba(5,4,16,${.22+(.18*(1-fade))})`;ctx.fillRect(0,0,w,h);
 const glow=ctx.createRadialGradient(w/2,h*.45,20,w/2,h*.45,320);glow.addColorStop(0,t.a+"22");glow.addColorStop(1,"#07061200");ctx.fillStyle=glow;ctx.fillRect(0,0,w,h);
 ctx.strokeStyle=t.a;ctx.globalAlpha=.45;ctx.lineWidth=2;
 for(let k=0;k<5;k++){ctx.beginPath();ctx.arc(180,300,65+k*36+Math.sin(time*2+k)*7,0,Math.PI*2);ctx.stroke();}
 ctx.globalAlpha=1;
 ctx.fillStyle="#fff";ctx.font="bold 17px sans-serif";ctx.fillText("NEON BEATS AI",22,42);
 ctx.fillStyle=t.a;ctx.font="bold 22px sans-serif";ctx.fillText(t.name,22,590);
 ctx.fillStyle="#fff";ctx.globalAlpha=.8;ctx.fillRect(22,606,316*(time/30),2);ctx.globalAlpha=1;
}
