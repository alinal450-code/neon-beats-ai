package com.neonbeats.ai

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.Executors
import android.util.Base64
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private val filePickerRequest = 4107
    private val ioExecutor = Executors.newSingleThreadExecutor()

    @Suppress("SetJavaScriptEnabled", "DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = true
            settings.mediaPlaybackRequiresUserGesture = false
            // The app loads only bundled local HTML/JS; this permits its JS to call the public HTTPS generator.
            settings.allowUniversalAccessFromFileURLs = true
            settings.javaScriptCanOpenWindowsAutomatically = false
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val scheme = request?.url?.scheme
                    return scheme !in listOf("file", "https", "http")
                }
            }
            webChromeClient = object : WebChromeClient() {
                override fun onShowFileChooser(
                    webView: WebView?,
                    callback: ValueCallback<Array<Uri>>?,
                    params: FileChooserParams?
                ): Boolean {
                    fileCallback?.onReceiveValue(null)
                    fileCallback = callback
                    val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "*/*"
                        putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*", "audio/*"))
                        putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                    }
                    startActivityForResult(intent, filePickerRequest)
                    return true
                }
            }
            addJavascriptInterface(NativeBridge(), "Android")
        }

        setContentView(FrameLayout(this).apply {
            addView(webView, FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            ))
        })
        webView.loadUrl("file:///android_asset/index.html")
    }

    inner class NativeBridge {
        @JavascriptInterface
        fun saveVideo(fileName: String, dataUri: String) {
            ioExecutor.execute {
                var ok = false
                var message = "Неизвестная ошибка"
                try {
                    val encoded = dataUri.substringAfter(",", "")
                    require(encoded.isNotBlank()) { "Пустой MP4-файл" }
                    val bytes = Base64.decode(encoded, Base64.DEFAULT)
                    val safeName = fileName.replace(Regex("[^A-Za-z0-9._-]"), "_")
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        val values = ContentValues().apply {
                            put(MediaStore.Video.Media.DISPLAY_NAME, safeName)
                            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                            put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/NEON BEATS AI")
                            put(MediaStore.Video.Media.IS_PENDING, 1)
                        }
                        val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                            ?: error("Не удалось создать файл в галерее")
                        contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                            ?: error("Не удалось записать видео")
                        values.clear()
                        values.put(MediaStore.Video.Media.IS_PENDING, 0)
                        contentResolver.update(uri, values, null, null)
                        message = "Movies/NEON BEATS AI"
                    } else {
                        val dir = File(getExternalFilesDir(Environment.DIRECTORY_MOVIES), "NEON BEATS AI")
                        if (!dir.exists()) dir.mkdirs()
                        FileOutputStream(File(dir, safeName)).use { it.write(bytes) }
                        message = dir.absolutePath
                    }
                    ok = true
                } catch (e: Exception) {
                    message = e.message ?: "Ошибка записи"
                }
                val callback = "window.onNativeSaveResult && window.onNativeSaveResult(${JSONObject.quote(fileName)},$ok,${JSONObject.quote(message)})"
                runOnUiThread { webView.evaluateJavascript(callback, null) }
            }
        }
    }

    @Deprecated("Deprecated in Android API; retained for WebView file chooser compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == filePickerRequest) {
            val results = if (resultCode == RESULT_OK && data != null) {
                val clip = data.clipData
                when {
                    clip != null -> Array(clip.itemCount) { i -> clip.getItemAt(i).uri }
                    data.data != null -> arrayOf(data.data!!)
                    else -> null
                }
            } else null
            fileCallback?.onReceiveValue(results)
            fileCallback = null
        }
    }

    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack()
        else super.onBackPressed()
    }

    override fun onDestroy() {
        if (::webView.isInitialized) webView.destroy()
        fileCallback?.onReceiveValue(null)
        fileCallback = null
        ioExecutor.shutdown()
        super.onDestroy()
    }
}
