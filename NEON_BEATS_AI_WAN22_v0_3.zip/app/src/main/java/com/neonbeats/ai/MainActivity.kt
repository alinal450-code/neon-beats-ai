package com.neonbeats.ai

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private val filePickerRequest = 4107
    private val executor = Executors.newSingleThreadExecutor()
    private val apiBase = "https://prithivmlmods-wan22-fast.hf.space"

    @Suppress("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = true
            settings.mediaPlaybackRequiresUserGesture = false
            addJavascriptInterface(NativeBridge(), "NeonNative")
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    return request?.url?.scheme !in listOf("file", "https", "http", "content", "blob")
                }
            }
            webChromeClient = object : WebChromeClient() {
                override fun onShowFileChooser(
                    webView: WebView?, callback: ValueCallback<Array<Uri>>?, params: FileChooserParams?
                ): Boolean {
                    fileCallback?.onReceiveValue(null)
                    fileCallback = callback
                    val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "*/*"
                        putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*", "audio/*"))
                        putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                    }
                    startActivityForResult(intent, filePickerRequest)
                    return true
                }
            }
        }
        setContentView(FrameLayout(this).apply {
            addView(webView, FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT
            ))
        })
        webView.loadUrl("file:///android_asset/index.html")
    }

    inner class NativeBridge {
        @JavascriptInterface
        fun generateVideo(imageData: String, prompt: String, callbackId: String) {
            executor.execute {
                try {
                    notifyProgress(callbackId, "Отправляем фото в Wan 2.2…")
                    val payload = JSONObject().apply {
                        put("image_b64", imageData)
                        put("prompt", prompt)
                        put("steps", 4)
                        put("negative_prompt", "blurry, low quality, distorted face, extra limbs, text, watermark, frozen image")
                        put("duration_seconds", 5.0)
                        put("guidance_scale", 1.0)
                        put("guidance_scale_2", 1.0)
                        put("seed", 42)
                        put("randomize_seed", true)
                    }
                    val post = (URL("$apiBase/gradio_api/call/generate_video").openConnection() as HttpURLConnection).apply {
                        requestMethod = "POST"
                        connectTimeout = 30000
                        readTimeout = 60000
                        doOutput = true
                        setRequestProperty("Content-Type", "application/json")
                        setRequestProperty("Accept", "application/json")
                    }
                    post.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
                    val postCode = post.responseCode
                    val postText = (if (postCode in 200..299) post.inputStream else post.errorStream)
                        ?.bufferedReader()?.use { it.readText() }.orEmpty()
                    post.disconnect()
                    if (postCode !in 200..299) throw Exception("Сервер ответил $postCode: ${postText.take(250)}")
                    val eventId = JSONObject(postText).optString("event_id")
                    if (eventId.isBlank()) throw Exception("Сервер не вернул номер задачи: ${postText.take(250)}")

                    notifyProgress(callbackId, "Задача в очереди ИИ. Ждём генерацию…")
                    val result = pollResult(eventId, callbackId)
                    val videoData = result.optString("video")
                    if (videoData.isBlank()) throw Exception("ИИ не вернул видеофайл")
                    val comma = videoData.indexOf(',')
                    val encoded = if (videoData.startsWith("data:") && comma >= 0) videoData.substring(comma + 1) else videoData
                    val bytes = android.util.Base64.decode(encoded, android.util.Base64.DEFAULT)
                    val uri = saveVideo(bytes)
                    runOnUiThread {
                        webView.evaluateJavascript("window.onNativeSuccess(${JSONObject.quote(callbackId)}, ${JSONObject.quote(uri.toString())})", null)
                    }
                } catch (e: Exception) {
                    val message = e.message ?: "Неизвестная ошибка генерации"
                    runOnUiThread {
                        webView.evaluateJavascript("window.onNativeError(${JSONObject.quote(callbackId)}, ${JSONObject.quote(message)})", null)
                    }
                }
            }
        }

        @JavascriptInterface
        fun cancel() { /* Current server requests finish or time out safely. */ }
    }

    private fun pollResult(eventId: String, callbackId: String): JSONObject {
        val conn = (URL("$apiBase/gradio_api/call/generate_video/$eventId").openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 30000
            readTimeout = 12 * 60 * 1000
            setRequestProperty("Accept", "text/event-stream")
        }
        val code = conn.responseCode
        if (code !in 200..299) {
            val err = conn.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
            conn.disconnect()
            throw Exception("Ошибка ожидания $code: ${err.take(250)}")
        }
        var event = ""
        val reader = BufferedReader(InputStreamReader(conn.inputStream, Charsets.UTF_8))
        try {
            while (true) {
                val line = reader.readLine() ?: break
                if (line.startsWith("event:")) event = line.substringAfter(':').trim()
                if (line.startsWith("data:")) {
                    val raw = line.substringAfter(':').trim()
                    if (event == "complete") return unwrapResult(raw)
                    if (event == "error") throw Exception(raw.take(400))
                    if (event == "status") notifyProgress(callbackId, "ИИ обрабатывает фото…")
                }
            }
        } finally {
            reader.close()
            conn.disconnect()
        }
        throw Exception("Соединение с ИИ завершилось до готового видео. Попробуй ещё раз.")
    }

    private fun unwrapResult(raw: String): JSONObject {
        val value = raw.trim()
        return try {
            val parsed = if (value.startsWith("[")) JSONArray(value).opt(0) else JSONObject(value)
            when (parsed) {
                is JSONObject -> parsed
                is String -> JSONObject(parsed)
                else -> throw Exception("Неверный формат ответа ИИ")
            }
        } catch (e: Exception) {
            throw Exception("Не удалось прочитать результат ИИ: ${value.take(180)}")
        }
    }

    private fun saveVideo(bytes: ByteArray): Uri {
        val name = "NEON_BEATS_AI_${System.currentTimeMillis()}.mp4"
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/NEON BEATS AI")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw Exception("Не удалось создать файл видео")
        try {
            contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                ?: throw Exception("Не удалось сохранить видео")
            values.clear()
            values.put(MediaStore.Video.Media.IS_PENDING, 0)
            contentResolver.update(uri, values, null, null)
            return uri
        } catch (e: Exception) {
            contentResolver.delete(uri, null, null)
            throw e
        }
    }

    private fun notifyProgress(id: String, message: String) {
        runOnUiThread {
            webView.evaluateJavascript("window.onNativeProgress(${JSONObject.quote(id)}, ${JSONObject.quote(message)})", null)
        }
    }

    @Deprecated("Deprecated API retained for WebView file chooser compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == filePickerRequest) {
            val results = if (resultCode == RESULT_OK && data != null) {
                val clip = data.clipData
                when {
                    clip != null -> Array(clip.itemCount) { i -> clip.getItemAt(i).uri }
                    data.data != null -> arrayOf(data.data!!)
                    else -> null
                }
            } else null
            fileCallback?.onReceiveValue(results)
            fileCallback = null
        }
    }

    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        executor.shutdownNow()
        if (::webView.isInitialized) webView.destroy()
        fileCallback?.onReceiveValue(null)
        fileCallback = null
        super.onDestroy()
    }
}
