const $ = id => document.getElementById(id);
let photos = [], trackFile = null, trackURL = null;
const photoInput = $("photos"), trackInput = $("track"), audio = $("audio"), createBtn = $("create");

photoInput.addEventListener("change", () => {
  photos = [...photoInput.files].filter(f => f.type.startsWith("image/")).slice(0, 8).map(file => ({ file, url: URL.createObjectURL(file) }));
  renderPhotos(); updateReady();
});
trackInput.addEventListener("change", () => {
  const f = trackInput.files[0]; if (!f) return;
  if (trackURL) URL.revokeObjectURL(trackURL);
  trackFile = f; trackURL = URL.createObjectURL(f); audio.src = trackURL; audio.hidden = false;
  $("trackInfo").innerHTML = `<strong>♫ ${escapeHTML(f.name)}</strong> · ${(f.size / 1048576).toFixed(1)} МБ`;
  updateReady();
});
function escapeHTML(s) { return s.replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }
function renderPhotos() {
  $("photoList").innerHTML = photos.length ? photos.map(p => `<img class="thumb" src="${p.url}" alt="Загруженное фото">`).join("") : '<span class="empty">Пока нет загруженных фото</span>';
}
function updateReady() {
  createBtn.disabled = photos.length === 0;
  $("message").textContent = createBtn.disabled ? "Добавь хотя бы одно фото." : "Фото готово. Нажми кнопку для настоящей ИИ-анимации.";
}
const themes = [
  { name: "NEON PULSE", desc: "Плавное кинематографичное движение", extra: "cinematic slow camera push-in, flowing neon pink and cyan lights, subtle hair and clothing movement, atmospheric night city" },
  { name: "NIGHT DRIVE", desc: "Ночной город и динамичная камера", extra: "dynamic tracking camera, night city lights moving in background, reflections, energetic underground music video atmosphere" },
  { name: "DREAM FLOW", desc: "Мягкий свет и плавное движение", extra: "dreamlike cinematic camera orbit, soft glowing particles, gentle wind, beautiful atmospheric lighting, smooth natural motion" }
];

function imageAsDataUrl(photo) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      const max = 832, scale = Math.min(1, max / Math.max(img.width, img.height));
      const canvas = document.createElement("canvas");
      canvas.width = Math.max(1, Math.round(img.width * scale));
      canvas.height = Math.max(1, Math.round(img.height * scale));
      canvas.getContext("2d").drawImage(img, 0, 0, canvas.width, canvas.height);
      resolve(canvas.toDataURL("image/jpeg", 0.86));
    };
    img.onerror = () => reject(new Error("Не удалось прочитать фотографию"));
    img.src = photo.url;
  });
}
function nativeGenerate(imageData, prompt, id) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error("Сервер слишком долго не отвечает. Попробуй позже.")), 11 * 60 * 1000);
    window.__neonCallbacks = window.__neonCallbacks || {};
    window.__neonCallbacks[id] = { resolve: uri => { clearTimeout(timer); resolve(uri); }, reject: err => { clearTimeout(timer); reject(new Error(err)); } };
    if (!window.NeonNative || !window.NeonNative.generateVideo) {
      clearTimeout(timer); delete window.__neonCallbacks[id]; reject(new Error("Не найден Android-модуль генерации. Установи свежий APK.")); return;
    }
    window.NeonNative.generateVideo(imageData, prompt, id);
  });
}
window.onNativeProgress = (id, message) => { const el = $("message"); if (el) el.textContent = message; };
window.onNativeSuccess = (id, uri) => { const cb = window.__neonCallbacks?.[id]; if (cb) { delete window.__neonCallbacks[id]; cb.resolve(uri); } };
window.onNativeError = (id, message) => { const cb = window.__neonCallbacks?.[id]; if (cb) { delete window.__neonCallbacks[id]; cb.reject(message); } };

createBtn.addEventListener("click", async () => {
  if (!photos.length) return;
  createBtn.disabled = true;
  $("results").hidden = false;
  $("variantGrid").innerHTML = "";
  const idea = $("idea").value.trim();
  try {
    const sourceImage = await imageAsDataUrl(photos[0]);
    for (let i = 0; i < themes.length; i++) {
      const theme = themes[i];
      const card = document.createElement("article");
      card.className = "variant";
      card.innerHTML = `<div class="ai-preview"><span class="ai-orbit"></span><b>WAN 2.2 AI</b><small>${theme.name}</small></div><h4>${theme.name}</h4><p>${theme.desc}</p><p class="generation-state">Подготовка запроса…</p>`;
      $("variantGrid").append(card);
      const state = card.querySelector(".generation-state");
      state.textContent = `Генерируем вариант ${i + 1} из 3…`;
      const prompt = `${idea ? idea + ". " : ""}${theme.extra}. Preserve the original person's identity, face, facial features, hairstyle, clothing and body proportions. Keep the main subject recognizable. High quality music video, vertical 9:16 composition.`;
      try {
        const uri = await nativeGenerate(sourceImage, prompt, `variant-${Date.now()}-${i}`);
        const video = document.createElement("video");
        video.controls = true; video.playsInline = true; video.src = uri;
        video.className = "generated-video";
        card.querySelector(".ai-preview").replaceWith(video);
        state.textContent = "Готово · сохранено в Галерею → Movies / NEON BEATS AI";
      } catch (err) {
        state.textContent = `Не получилось: ${err.message}`;
        state.classList.add("error");
        break;
      }
    }
    const failed = [...document.querySelectorAll(".generation-state.error")].length;
    $("message").textContent = failed ? "Генерация остановлена из-за ошибки сервера. Уже готовые видео сохранены в Галерее." : "Готово. Видео сохранены в Галерее телефона → Movies / NEON BEATS AI.";
  } catch (err) {
    $("message").textContent = "Ошибка: " + err.message;
  } finally {
    createBtn.disabled = false;
  }
});
